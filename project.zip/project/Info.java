import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.IOException;

class Info {

	Font f;
	Game game;
	Color[] healthColor;

	public void render(Graphics g) {
		g.drawImage(game.backImg, 28, 0, null);
		g.setColor(new Color(230, 230, 230));
		g.setFont(f);
		g.drawString(Integer.toString(game.energy), 240, 40);


		if (game.health > 0)
			g.setColor(healthColor[game.health-1]);

		for (int i=0; i<game.health; i++)
		{
			g.fillRect(845 + (i * 32), 15, 20, 20);
		}
	}

	Info(Game game) {

		try {
		GraphicsEnvironment ge = 
		GraphicsEnvironment.getLocalGraphicsEnvironment();
		ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("Amatic-Bold.ttf")));
		} catch (IOException e) {
				//ignoring as the system will use default font
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		f = new Font("Amatic", 0, 35);

		healthColor = new Color[4];
	
		healthColor[0] = new Color (255, 0, 0);
		healthColor[1] = new Color (255, 213, 0);
		healthColor[2] = new Color (0, 200, 0);


		this.game = game;
	}




}

