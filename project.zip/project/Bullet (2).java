
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Bullet extends GameObject {
	private Handler handler;
	Game game;

	public Bullet(int x, int y, ID id, Handler handler, int mx, int my, Game game) {
		super(x, y, id);
		this.handler = handler;
		velX = (mx - x) / 10;
		velY = (my - y) / 10;

		this.game = game;
	}

	@Override
	public void tick() {
		x += velX;
		y += velY;

		for (int i = 1; i < handler.object.size(); i++) {
			GameObject tempobject = handler.object.get(i);
			if (tempobject.getId() == ID.Block) {
				if (getBounds().intersects(tempobject.getBounds())) {
                 			handler.removeObject(this);
				}

			}
		}
	}

	@Override
	public void render(Graphics g) {
		g.drawImage(game.bltImg, x, y, null);
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle(x, y, 16, 24);
	}

}
