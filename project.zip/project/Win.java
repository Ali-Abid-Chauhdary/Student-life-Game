import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.io.FileWriter;

class Win {
	Game game;

	public Win(Game game) {
		this.game = game;
		
	}

	public void render(Graphics g) {

		g.drawImage(game.wonImg, 0, 0, null);

		g.setFont(new Font("Amatic", 0, 60));
		g.setColor(Color.white);

		g.drawString(Integer.toString(game.score) + ((game.score == 1) ? " second": " seconds"), 660, 95);
	
		int best=0;
		try {
		Scanner sc = new Scanner(new File("best.txt"));
		best = sc.nextInt();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		if (best == 0 || game.score < best) {	//blank file or new best score (lower is better)
			best = game.score;
			writeScoresToFile(best);
			
		}
		g.drawString(Integer.toString(best) + ((game.score == 1) ? " second": " seconds"), 660, 160);


	}

	private static boolean writeScoresToFile(int score) {
		FileWriter w1 = null;
		boolean success = false;

		try {
			w1 = new FileWriter("best.txt");
			w1.write(Integer.toString(score));
			success = true;
			
		}
		catch (IOException e) {
			success = false;
			e.printStackTrace();
		}
		catch (Exception e) {
			success = false;
			e.printStackTrace();
		}
		finally {
			try {
			if (w1 != null)
				w1.close();
			}
			catch (Exception e) {
			success = false;
			e.printStackTrace();
			}
		}

		return success;
	}
}
