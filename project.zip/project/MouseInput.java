import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MouseInput extends MouseAdapter {
	private Handler handler;
	private Camera camera;
	private Game game;

	public MouseInput(Handler handler, Camera camera, Game game) {
		this.handler = handler;
		this.camera = camera;
		this.game = game;
	}

	public void mousePressed(MouseEvent e) {

		
		int x = e.getX();
		int y = e.getY();

		int mx = (int) (e.getX() + camera.getX());
		int my = (int) (e.getY() + camera.getY());


		//exit button check if menu is not focused

		if ( x > 150 && x < 890 && y > 420 && y < 570  && game.menu) {
			System.exit(0);
		}



		GameObject tempobject = handler.object.get(0);

		if (tempobject.getId() == ID.Player && !game.menu && !game.isOver && !game.win && game.energy > 0)
		{
		
			Bullet m = new Bullet(tempobject.getX() + 16,
					tempobject.getY() + 24, ID.Bullet, handler, mx, my, game);				
			handler.addObject(m);

			game.energy --;

		}



		//game win options
		if (game.win) {

			game.again = false;
			game.quit = false;
			game.isRunning = true;

			game.menu = true;
		}

		//game over buttons
		if (game.isOver && !game.win) {
			//again button
			if (x > 420 && x < 495 && y > 300 && y < 340) {
				game.again = true;

			}
			//quit button
			else if (x < 580 && x > 500 && y < 340 && y > 300) {
				game.quit = true;
			}
		}

		//menu buttons
		if (game.menu) {
		if (x > 150 && x < 890) {
			//play button
			if (y > 32 && y < 182) {
				game.menu = false;

				game.startTime = System.currentTimeMillis();

				if (game.win) {
			
					game.again = true;
					game.isOver = false;
					game.isRunning = false;
					game.win = false;
				}
			}
			//high scores button
			else if (y > 230 && y < 380) {
			}
		}
		}
	}
}

