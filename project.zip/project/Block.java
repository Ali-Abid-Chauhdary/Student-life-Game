

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Block extends GameObject {

	Game game;

	public Block(int x, int y, ID id, Game game) {
		super(x, y, id);
		this.game = game;
	}

	public void tick() {

	}

	public void render(Graphics g) {
		g.drawImage(game.blkImg, x, y, null);

	}

	public Rectangle getBounds() {
		return new Rectangle(x, y, 32, 32);
	}

}
b
