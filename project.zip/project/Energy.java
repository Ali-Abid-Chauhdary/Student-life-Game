import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;


public class Energy extends GameObject{

	Game game;

	public Energy(int x, int y, ID id, Game game) {
		super(x, y, id);

		this.game = game;
	}

	@Override
	public void tick() {
		
		
	}

	@Override
	public void render(Graphics g) {
		g.drawImage(game.bkImg, x, y, null);
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle(x,y,32,32);
	}

	

}
