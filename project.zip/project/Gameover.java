import java.awt.Graphics;

class Gameover {
	Game game;

	public Gameover(Game game) {
		this.game = game;
	}

	public void render(Graphics g) {
		g.drawImage(game.govImg, 370, 230, null);
	}
}
