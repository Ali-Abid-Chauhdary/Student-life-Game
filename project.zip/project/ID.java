public enum ID {
	Player(), Block(), Enemy(), Bullet(), Crate(),
}
