import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class keyInput extends KeyAdapter {
	Handler handler;

	public keyInput(Handler handler) {
		this.handler = handler;
	}

	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
	
		if (key == KeyEvent.VK_UP)
			handler.setUp(true);
		if (key == KeyEvent.VK_DOWN)
			handler.setDown(true);
		if (key == KeyEvent.VK_LEFT)
			handler.setLeft(true);
		if (key == KeyEvent.VK_RIGHT)
			handler.setRight(true);	

		
	}

	public void keyReleased(KeyEvent e) {
		int key = e.getKeyCode();
		
		if (key == KeyEvent.VK_UP)
			handler.setUp(false);
		if (key == KeyEvent.VK_DOWN)
			handler.setDown(false);
		if (key == KeyEvent.VK_LEFT)
			handler.setLeft(false);
		if (key == KeyEvent.VK_RIGHT)
			handler.setRight(false);
	}

}
