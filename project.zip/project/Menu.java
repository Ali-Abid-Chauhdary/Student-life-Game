import java.awt.Graphics;

class Menu {
	Game game;

	public Menu(Game game) {
		this.game = game;
	}

	public void render(Graphics g) {
		g.drawImage(game.mainImg, 0, 0, null);
	}

}
