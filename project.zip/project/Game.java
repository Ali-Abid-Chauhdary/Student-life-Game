import java.awt.Canvas;//to add the canvas on the jFrame
import java.awt.Color; //to add color to the game
import java.awt.Graphics; //to add graphics content to the game
import java.awt.Graphics2D; //to translate into 2d Graphics
import java.awt.image.BufferStrategy; //to handle complex memory elements on the canvas
import java.awt.image.BufferedImage;//to load image into the memory
import java.awt.Image; //to read image
import java.awt.RenderingHints; //manages all the content of the keys

import javax.imageio.ImageIO ;//returns the read image
import java.io.File;//use for file handling
import java.io.IOException; //throws IO Exception
import java.util.Random; //used for generating random numbers
import java.util.concurrent.TimeUnit; //returns time in different time units

public class Game extends Canvas implements Runnable {
    //starts the main thread
	private static final long serialVersionUID = 1L;
	public boolean isRunning = false;
	private Thread thread;
	private Handler handler;
	private BufferedImage level;
	private Info info;
	private Gameover gameover;
	private Win winM;	//Win message

	BufferedImage plrImg;
	BufferedImage bltImg;
	BufferedImage blkImg;
	BufferedImage bkImg;
	BufferedImage backImg;
	BufferedImage govImg;
	BufferedImage mainImg;
	BufferedImage wonImg;


	BufferedImage[] enImg;

	long startTime;

	boolean isOver;
	boolean again = false;
	boolean quit = false;
	boolean menu = false;
	boolean win = false;

	private Camera camera;
	public int energy;
	public int health;
	public Menu myMenu;
	public int score;

		keyInput ki;
		MouseInput mi;

	public Game() {

		//Loading required images
		try {
			enImg = new BufferedImage[4];

			plrImg = ImageIO.read(new File("plrimg.png"));
			bltImg = ImageIO.read(new File("bltimg.png"));
			blkImg = ImageIO.read(new File("blkimg.jpg"));
			bkImg = ImageIO.read(new File("bkimg.png"));
			backImg = ImageIO.read(new File("backimg.png"));
			govImg = ImageIO.read(new File("govimg.png"));
			mainImg = ImageIO.read(new File("mainimg.jpg"));
			wonImg = ImageIO.read(new File("wonimg.jpg"));

			enImg[0] = ImageIO.read(new File("qimg.png"));
			enImg[1] = ImageIO.read(new File("fimg.png"));
			enImg[2] = ImageIO.read(new File("hwimg.png"));
			enImg[3] = ImageIO.read(new File("tstimg.png"));

		} catch (IOException e) {
			e.printStackTrace();
		}
		catch (Exception e) {

			e.printStackTrace();
		}
		finally{
		}


		new Window(1000, 630, "Wizard Shooter", this);


		menu = true;

		do {
		handler = new Handler();
		myMenu = new Menu(this);
		gameover = new Gameover(this);
		winM = new Win(this);
		camera = new Camera(0, 0);
		info = new Info(this);
		energy = 10;

		startTime = System.currentTimeMillis();

		again = false;
		quit = false;
		win = false;
		isOver = false;

		ki = new keyInput(handler);
		mi = new MouseInput(handler,camera,this);

		this.addKeyListener(ki);
		this.addMouseListener(mi);




		BufferedImageLoader loader = new BufferedImageLoader();
		level = loader.loadImage("wizard_level.png");
		loadLevel(level);

		start();


		try {
			thread.join();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

			while (!again && !quit){

			try {

			TimeUnit.MILLISECONDS.sleep(20);
			}
			catch (Exception e){
				e.printStackTrace();
			}

			}

		this.removeKeyListener(ki);
		this.removeMouseListener(mi);

		} while (again);

		if (quit)
          	  System.exit(0);

	}

	private void start() {
		isRunning = true;
		thread = new Thread(this);
		thread.start();
	}

	private void stop() {
		isRunning = false;
		try {
			thread.join();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public void run() {

		this.requestFocus();
		long lasttime = System.currentTimeMillis();
		long now;

		while (isRunning) {
			now = System.currentTimeMillis();

			//rendering after 20 millisecond. 1000/20 = 50 frames per second
			if ((now - lasttime) >= 20) {
				tick();
				render();
				lasttime = now;
			}
		}

System.out.println("Finished.");

	}

	public void tick() {

		if (!isOver && !menu) {
			camera.tick(handler.object.get(0));	//first object is player
			handler.tick();

			if (handler.nEnemiesFood < 1) {	//all enemies and quizzes, tests, etc. finished
				isOver = true;
				win = true;
				score = (int) (System.currentTimeMillis() - startTime)/1000;
				handler.object.remove(0);	//player
			}
		}
	}

	public void render() {

		BufferStrategy bs = this.getBufferStrategy();
		if (bs == null) {
			this.createBufferStrategy(2);
			return;
		}
		Graphics g = bs.getDrawGraphics();
		Graphics2D g2d = (Graphics2D) g;

		//System.out.println(isOver+", "+again+", "+quit+", "+menu+", "+win);

		if (!menu) {

		///////////////////////////////////////////////
		g.setColor(Color.white);
		g.fillRect(0, 0, 1000, 630);

		g2d.setRenderingHint(
      	  	RenderingHints.KEY_TEXT_ANTIALIASING,
       		RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

		g2d.translate(-camera.getX(), -camera.getY());
		handler.render(g);
		g2d.translate(camera.getX(), camera.getY());
		info.render(g);

		if (isOver) {
			if (!win) {
				gameover.render(g);
				isRunning = false;
			}
			else {
				winM.render(g);
			}

		}
		}
		else {

			myMenu.render(g);
		}

		g.dispose();
		bs.show();
	}

	private void loadLevel(BufferedImage image) {
		int w = image.getWidth();
		int h = image.getHeight();

		Random rn = new Random(System.currentTimeMillis());

		for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++) {
				int pixel = image.getRGB(x, y);
				int red = (pixel >> 16) & 0xff;
				int green = (pixel >> 8) & 0xff;
				int blue = (pixel) & 0xff;
				if (red == 255)
					handler.addObject(new Block(x * 32, y * 32, ID.Block, this));
				if (blue == 255 && green == 0 && red == 0)	//player must be the first object
					handler.object.set(0, new Player(x * 32, y * 32, ID.Player,handler, this));
				if(green == 255 )			//adding random picture
					handler.addObject(new Enemy(x * 32, y * 32,ID.Enemy,handler, enImg[rn.nextInt(4)]));
				if(green ==255 && blue == 255)
					handler.addObject(new Energy(x*32,y*32,ID.Crate, this));
			}

	}

	public static void main(String[] args) {
		new Game();
	}

}
